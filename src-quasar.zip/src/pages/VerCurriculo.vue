<template>
  <q-page padding class="row justify-center">
    <div style="width: 80%">
      <div class="q-pt-md">
        <h6 class="text-primary" style="margin-bottom: 1em">
          Andressa Moura Souza
        </h6>
        <h6 style="margin: 0.5em 0">Endereço</h6>
        <p>Avenida Palmas, 145 Centro - ITÁPOLIS - SP</p>
        <h6 style="margin: 0.5em 0">Número de contato</h6>
        <p>(016) 32365544</p>
      </div>

      <div>
        <h6 class="text-primary" style="margin-bottom: .5em">Sobre o candidato</h6>
        <div class="row justify-between" style="width: 350px">
          <div>
            <h6 style="margin: .5em 0">Experiência</h6>
            <p>Sim</p>
          </div>
          <div>
            <h6 style="margin: .5em 0">Escolaridade</h6>
            <p>Ensino incompleto</p>
          </div>
        </div>
      </div>
    </div>
  </q-page>
</template>